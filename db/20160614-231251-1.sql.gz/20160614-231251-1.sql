-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2016-06-14 23:12:51
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `cy_log`
-- -----------------------------
DROP TABLE IF EXISTS `cy_log`;
CREATE TABLE `cy_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `log` text NOT NULL,
  `ip` varchar(16) NOT NULL,
  `t` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cy_log`
-- -----------------------------
INSERT INTO `cy_log` VALUES ('1', 'admin', '优化表：cy_log`,`cy_menu`,`cy_setting`,`cy_user`,`cy_user_group', '127.0.0.1', '1465915675');
INSERT INTO `cy_log` VALUES ('2', 'admin', '修复表：cy_log`,`cy_menu`,`cy_setting`,`cy_user`,`cy_user_group', '127.0.0.1', '1465915677');
INSERT INTO `cy_log` VALUES ('3', 'admin', '备份文件删除成功！', '127.0.0.1', '1465916734');
INSERT INTO `cy_log` VALUES ('4', 'admin', '备份完成！', '127.0.0.1', '1465917159');
INSERT INTO `cy_log` VALUES ('5', 'admin', '备份完成！', '127.0.0.1', '1465917166');
INSERT INTO `cy_log` VALUES ('6', 'admin', '备份完成！', '127.0.0.1', '1465917168');

-- -----------------------------
-- Table structure for `cy_menu`
-- -----------------------------
DROP TABLE IF EXISTS `cy_menu`;
CREATE TABLE `cy_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL COMMENT '父级ID',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '连接',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(100) NOT NULL COMMENT '图标',
  `tips` varchar(255) NOT NULL COMMENT '提示语',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1显示，0隐藏',
  `o` tinyint(4) NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `url` (`url`),
  KEY `status` (`status`),
  KEY `o` (`o`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cy_menu`
-- -----------------------------
INSERT INTO `cy_menu` VALUES ('1', '0', 'index/index', '控制台', 'menu-icon fa fa-tachometer', '', '1', '1');
INSERT INTO `cy_menu` VALUES ('2', '0', '#', '开发选项', 'menu-icon fa fa-cogs', '', '1', '2');
INSERT INTO `cy_menu` VALUES ('3', '2', 'menu/index', '后台菜单', 'menu-icon fa  fa-folder-o', '开发新功能，新增、修改、删除后台菜单。', '1', '3');
INSERT INTO `cy_menu` VALUES ('4', '2', 'variable/index', '自定义变量', 'menu-icon fa  fa-circle-o', '秀', '1', '4');
INSERT INTO `cy_menu` VALUES ('5', '0', '#', '系统设置', 'menu-icon fa fa-cog', '大', '1', '5');
INSERT INTO `cy_menu` VALUES ('6', '5', 'setting/index', '网站设置', 'menu-icon fa  fa-info-circle', '', '1', '6');
INSERT INTO `cy_menu` VALUES ('7', '5', 'database/backup', '数据库备份', 'menu-icon fa fa-floppy-o', '', '1', '7');
INSERT INTO `cy_menu` VALUES ('8', '5', 'database/recovery', '数据还原', 'menu-icon fa fa-undo', '数据库还原', '1', '10');
INSERT INTO `cy_menu` VALUES ('9', '5', 'database/optimize', '数据优化', '', '', '0', '0');
INSERT INTO `cy_menu` VALUES ('10', '5', 'database/repair', '数据修复', '', '', '0', '0');

-- -----------------------------
-- Table structure for `cy_setting`
-- -----------------------------
DROP TABLE IF EXISTS `cy_setting`;
CREATE TABLE `cy_setting` (
  `k` varchar(100) NOT NULL COMMENT '变量',
  `v` varchar(255) NOT NULL COMMENT '值',
  `name` varchar(255) NOT NULL,
  `tips` varchar(255) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '0系统，1自定义',
  `o` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`k`),
  KEY `k` (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cy_setting`
-- -----------------------------
INSERT INTO `cy_setting` VALUES ('title', '春燕网络通用后台管理系统', '网站名称', '长度255个汉字内', '0', '0');
INSERT INTO `cy_setting` VALUES ('sitename', 'CYAdmin', '短标题', '长度255个汉字内', '0', '0');
INSERT INTO `cy_setting` VALUES ('keywords', '关键词', '关键词', '长度255个汉字内', '0', '0');
INSERT INTO `cy_setting` VALUES ('description', '网站描述', '网站描述', '长度255个汉字内', '0', '0');
INSERT INTO `cy_setting` VALUES ('footer', '©2016 春燕网络', '版权信息', '长度255个汉字内', '0', '0');
INSERT INTO `cy_setting` VALUES ('test', '你好', '自定义变量', '磊', '1', '0');
INSERT INTO `cy_setting` VALUES ('test1', 'have a test', '自定义变量', '', '1', '0');
INSERT INTO `cy_setting` VALUES ('tt', '变量值', '自定义变量', '', '1', '0');
INSERT INTO `cy_setting` VALUES ('te', '变量值在地', '自定义变量', '', '1', '0');

-- -----------------------------
-- Table structure for `cy_user`
-- -----------------------------
DROP TABLE IF EXISTS `cy_user`;
CREATE TABLE `cy_user` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `ugid` int(10) unsigned NOT NULL COMMENT '用户组ID',
  `username` varchar(100) DEFAULT NULL COMMENT '管理员账号',
  `password` varchar(32) DEFAULT NULL COMMENT '管理员密码',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '账户状态，禁用为0   启用为1',
  `identifier` varchar(32) NOT NULL,
  `token` varchar(32) NOT NULL,
  `salt` varchar(10) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`,`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cy_user`
-- -----------------------------
INSERT INTO `cy_user` VALUES ('1', '1', 'admin', 'e62e76cff8e27165bbf2eb429506da72', '1', 'e809ff4654312c20b27a33eb5488ef3b', 'e4e043928902ada7fe4c538f23bc50ff', '9UnEntzaNX');

-- -----------------------------
-- Table structure for `cy_user_group`
-- -----------------------------
DROP TABLE IF EXISTS `cy_user_group`;
CREATE TABLE `cy_user_group` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `auth` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cy_user_group`
-- -----------------------------
INSERT INTO `cy_user_group` VALUES ('1', '超级管理组', '1', '
1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200');
